from flask import Flask, render_template
app = Flask(__name__)

@app.route('/')
def index():
    return render_template ("index.html")

@app.route('/login')
def login():
    return render_template ("login.html")

@app.route('/base')
def base():
    return render_template ("base.html")

@app.route('/perfil')
def perfil():
    return render_template ("perfil.html")

@app.route('/dashboard')
def dashboard():
    return render_template ("dashboard.html")

@app.route('/dashboard_2')
def dashboard_2():
    return render_template ("dashboard_2.html")

@app.route('/dashboard_3')
def dashboard_3():
    return render_template ("dashboard_3.html")

@app.route('/dashboard_4')
def dashboard_4():
    return render_template ("dashboard_4.html")

@app.route('/herramientas')
def herramientas():
    return render_template ("herramientas.html")

@app.route('/herramientas_2')
def herramientas_2():
    return render_template ("herramientas_2.html")

@app.route('/herramientas_3')
def herramientas_3():
    return render_template ("herramientas_3.html")

@app.route('/herramientas_4')
def herramientas_4():
    return render_template ("herramientas_4.html")

@app.route('/usuarios')
def usuarios():
    return render_template ("usuarios.html")


if __name__ == "__main__":
    app.run(debug=True)